import * as actionTypes from "./typeofActions";

const updateObject = (oldObject, updatedProperties) => {
    return {
        ...oldObject,
        ...updatedProperties,
    };
};

const initialState = {
    token: null,
    user_id: null,
    user: null,
    error: null,
    loading: false,

    authRedirectPath: "/",
};

const sendCodeStart = (state, action) => {
    return updateObject(state, { error: null, loading: true });
};

const sendCodeSuccess = (state, action) => {
    return updateObject(state, {
        user_id: action.user_id,
        error: null,
        loading: false,
    });
};

const sendCodeFail = (state, action) => {
    return updateObject(state, {
        error: action.error,
        loading: false,
    });
};

const verifyCodeStart = (state, action) => {
    return updateObject(state, { error: null, loading: true });
};

const verifyCodeSuccess = (state, action) => {
    return updateObject(state, {
        token: action.token,
        user: action.user,
        error: null,
        loading: false,
    });
};

const verifyCodeFail = (state, action) => {
    return updateObject(state, {
        error: action.error,
        loading: false,
    });
};
const authLogout = (state, action) => {
    return updateObject(state, { token: null, userId: null });
};

const setAuthRedirectPath = (state, action) => {
    return updateObject(state, { authRedirectPath: action.path });
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.SEND_CODE_START:
            return sendCodeStart(state, action);
        case actionTypes.SEND_CODE_SUCCESS:
            return sendCodeSuccess(state, action);
        case actionTypes.SEND_CODE_FAIL:
            return sendCodeFail(state, action);
        case actionTypes.VERIFY_CODE_START:
            return verifyCodeStart(state, action);
        case actionTypes.VERIFY_CODE_SUCCESS:
            return verifyCodeSuccess(state, action);
        case actionTypes.VERIFY_CODE_FAIL:
            return verifyCodeFail(state, action);
        case actionTypes.AUTH_LOGOUT:
            return authLogout(state, action);
        // // case actionTypes.SET_AUTH_REDIRECT_PATH:
        // //     return setAuthRedirectPath(state, action);

        default:
            return state;
    }
};

export default reducer;
