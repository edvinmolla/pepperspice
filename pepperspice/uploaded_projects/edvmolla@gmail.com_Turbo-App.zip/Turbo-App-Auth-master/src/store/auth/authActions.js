import * as actionTypes from "./typeofActions";
import axios from "axios";

export const sendCodeStart = () => {
    return {
        type: actionTypes.SEND_CODE_START,
    };
};

export const sendCodeSuccess = (user_id) => {
    return {
        type: actionTypes.SEND_CODE_SUCCESS,

        user_id: user_id,
    };
};

export const sendCodeFail = (error) => {
    return {
        type: actionTypes.SEND_CODE_FAIL,
        error: error,
    };
};

export const Logout = () => {
    localStorage.removeItem("token");
    // localStorage.removeItem("userID");

    return {
        type: actionTypes.AUTH_LOGOUT,
    };
};

export const chekAuthTime = (authTime) => {
    return (dispatch) => {
        setTimeout(() => {
            dispatch(Logout());
        }, authTime * 1000);
    };
};

export const sendCode = (phone) => {
    return (dispatch) => {
        dispatch(sendCodeStart());
        const authData = {
            phone: phone,
        };
        let url = "https://develop.almotech.co/turboo/public/api/send_code";

        axios
            .post(url, authData)
            .then((response) => {
                dispatch(sendCodeSuccess(response.data.user_id));
            })
            .catch((err) => {
                dispatch(sendCodeFail(err.response.data.error));
            });
    };
};

export const verifyCodeStart = () => {
    return {
        type: actionTypes.VERIFY_CODE_START,
    };
};

export const verifyCodeSuccess = (token, user) => {
    return {
        type: actionTypes.VERIFY_CODE_SUCCESS,
        token: token,
        user: user,
    };
};

export const verifyCodeFail = (error) => {
    return {
        type: actionTypes.VERIFY_CODE_FAIL,
        error: error,
    };
};

export const verifyCode = (user_id, code) => {
    return (dispatch) => {
        dispatch(verifyCodeStart());
        const authData = {
            user_id: user_id,
            code: code,
            platform: "Web",
            firebase_token: "assadasd",
        };
        let url = "https://develop.almotech.co/turboo/public/api/verify_code";

        axios
            .post(url, authData)
            .then((response) => {
                console.log(response.data);

                // const expirationDate = new Date(new Date().getTime() + response.data.expiresIn * 1000);
                localStorage.setItem("token", response.data.token);

                localStorage.setItem("user", JSON.stringify(response.data.data));

                dispatch(verifyCodeSuccess(response.data.token, response.data.data));
                // dispatch(chekAuthTime(response.data.expiresIn));
            })
            .catch((err) => {
                dispatch(verifyCodeFail(err.response.data.error));
            });
    };
};

// export const setAuthRedirectPath = (path) => {
//     return {
//         type: actionTypes.SET_AUTH_REDIRECT_PATH,
//         path: path,
//     };
// };

export const authCheckState = () => {
    console.log("hi");

    return (dispatch) => {
        const token = localStorage.getItem("token");
        const user = localStorage.getItem("user");

        if (!token) {
            dispatch(Logout());
        } else {
            dispatch(verifyCodeSuccess(token, JSON.parse(user)));
            // dispatch(chekAuthTime(expirationDate.getTime() - new Date().getTime() / 1000));
        }
    };
};
