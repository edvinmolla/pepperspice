import quickviewReducer from './quickviewReducer';

export * from './quickviewActions';
export default quickviewReducer;
