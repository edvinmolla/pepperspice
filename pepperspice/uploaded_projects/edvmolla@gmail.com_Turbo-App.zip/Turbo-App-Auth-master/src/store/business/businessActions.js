import * as actionTypes from "./typeActions";
import axios from "axios";

export const fetchCategoriesStart = () => {
    return {
        type: actionTypes.FETCH_CATEGORIES_START,
    };
};

export const fetchCategoriesSuccess = (categories) => {
    return {
        type: actionTypes.FETCH_CATEGORIES_SUCCESS,
        categories: categories,
    };
};

export const fetchCategoriesFail = (error) => {
    return {
        type: actionTypes.FETCH_CATEGORIES_FAIL,
        error: error,
    };
};

export const fetchBusinessByCategory = (busniess) => {
    return {
        type: actionTypes.FETCH_BUSINESS_BY_CATEGORY,
        busniess: busniess,
    };
};
export const fetchBusinessRandom = (random_businesses) => {
    return {
        type: actionTypes.FETCH_RANDOM_BUSINESS,
        random_businesses: random_businesses,
    };
};

export const fetchBusinessCategory = (token) => {
    return (dispatch) => {
        dispatch(fetchCategoriesStart());

        let deftoken;
        if (token) {
            deftoken = token;
        } else {
            deftoken =
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI1IiwianRpIjoiZWE0OTZkNDRiNTMxOThmZTc3OTJlMzZiYzI1OTFmYTkzODFiMTg2NGE4NTljZjlkOGQ1MjNjY2EzMmQ2Mjc5MTQzNzdmMWJhNGRlZjZjZTciLCJpYXQiOjE1ODcxMjQ2NjEsIm5iZiI6MTU4NzEyNDY2MSwiZXhwIjoxNjE4NjYwNjYxLCJzdWIiOiIxIiwic2NvcGVzIjpbXX0.e4ftMKofbBWGQ0vk6yGZv0qLgQK2GqCuYWWL1LPdkZYCmESLwBNwSWEf81IrJAYRyY03CivjUTmAIPUqBLwy1sWJrBnF7z9ukV37fripZXk1EFi7-j1iQbuhPmZRDfvQxIZoilRE4NqBNnN0nDFv1f7tYldAZGrOHsZlVkjTUlSe55hs0Xw6kYVduSv63Y_jBRl5jssGp9xyxHwCWjVvy17z1tYlmhTX_UwAjXlZ-l4nrNwY033sJbqvjDW1506XrefG8fpPsJgm0S2VeWKHaRuatZn_8oFH56dPLvjGHs6X_bm5DKaAMwwFh8r6GW3aidZ5wwmc5_nSHiZ9CMdp-q97a2tj_v-m2RLeKPyZlp2zE6sV9sYfDfKc6ouzfVlhicM9QgUYokktm2mMMDLUWvHSuCvC4WlL_sacYdqnARpOyZ6FBMnLvuXfB6qqh0eJyuMuZwjZJWNhYyqu89dMmzesBi85NZZSHz4Jn9worIL5MSk5NOa9bzKvoJgc-z1GNamQkumQKRXOweQi-wfn-ymagB1e1PIhejVvPZik0vud5n0ZbUSSVEbq_8iJ0EvwZeP-gKkx9nmiXL-cxd569_iTI2imbWoOeeanQoCqa9QJysoKY7AUFetycpfUX8XLXBaF1cuFoMiChXbBTCkYVf9cFhHenycN9Y4gQ1uuAGs";
        }

        const config = {
            headers: {
                Authorization: `Bearer ${deftoken}`,
            },
        };

        axios
            .get("https://develop.almotech.co/turboo/public/api/business_categories", config)
            .then((res) => {
                let categories = res.data;
                let randomBusiness = res.data.random_businesses;

                dispatch(fetchCategoriesSuccess(categories));
                dispatch(fetchBusinessRandom(randomBusiness));
            })
            .catch((e) => {
                dispatch(fetchCategoriesFail(e));
            });
    };
};

export const onfetchBusinessByCategory = (categoryId, token) => {
    return (dispatch) => {
        let deftoken;
        if (token) {
            deftoken = token;
        } else {
            deftoken =
                "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI1IiwianRpIjoiZWE0OTZkNDRiNTMxOThmZTc3OTJlMzZiYzI1OTFmYTkzODFiMTg2NGE4NTljZjlkOGQ1MjNjY2EzMmQ2Mjc5MTQzNzdmMWJhNGRlZjZjZTciLCJpYXQiOjE1ODcxMjQ2NjEsIm5iZiI6MTU4NzEyNDY2MSwiZXhwIjoxNjE4NjYwNjYxLCJzdWIiOiIxIiwic2NvcGVzIjpbXX0.e4ftMKofbBWGQ0vk6yGZv0qLgQK2GqCuYWWL1LPdkZYCmESLwBNwSWEf81IrJAYRyY03CivjUTmAIPUqBLwy1sWJrBnF7z9ukV37fripZXk1EFi7-j1iQbuhPmZRDfvQxIZoilRE4NqBNnN0nDFv1f7tYldAZGrOHsZlVkjTUlSe55hs0Xw6kYVduSv63Y_jBRl5jssGp9xyxHwCWjVvy17z1tYlmhTX_UwAjXlZ-l4nrNwY033sJbqvjDW1506XrefG8fpPsJgm0S2VeWKHaRuatZn_8oFH56dPLvjGHs6X_bm5DKaAMwwFh8r6GW3aidZ5wwmc5_nSHiZ9CMdp-q97a2tj_v-m2RLeKPyZlp2zE6sV9sYfDfKc6ouzfVlhicM9QgUYokktm2mMMDLUWvHSuCvC4WlL_sacYdqnARpOyZ6FBMnLvuXfB6qqh0eJyuMuZwjZJWNhYyqu89dMmzesBi85NZZSHz4Jn9worIL5MSk5NOa9bzKvoJgc-z1GNamQkumQKRXOweQi-wfn-ymagB1e1PIhejVvPZik0vud5n0ZbUSSVEbq_8iJ0EvwZeP-gKkx9nmiXL-cxd569_iTI2imbWoOeeanQoCqa9QJysoKY7AUFetycpfUX8XLXBaF1cuFoMiChXbBTCkYVf9cFhHenycN9Y4gQ1uuAGs";
        }

        const config = {
            headers: {
                Authorization: `Bearer ${deftoken}`,
            },
        };

        axios
            .get(`https://develop.almotech.co/turboo/public/api/businesses_by_category/${categoryId}`, config)
            .then((res) => {
                let busniess = res.data;

                dispatch(fetchBusinessByCategory(busniess));
            })
            .catch((e) => {
                dispatch(fetchCategoriesFail(e));
            });
    };
};
