import * as actionTypes from "./typeActions";

const initialState = {
    categories: [],
    busniess: [],
    loading: false,
    random_businesses: [],
};

const fetchCategoriesStart = (state, action) => {
    return {
        ...state,
        loading: true,
    };
};
const fetchCategoriesSuccess = (state, action) => {
    return {
        ...state,
        categories: action.categories,
        loading: false,
    };
};
const fetchCategoriesFail = (state, action) => {
    return {
        ...state,
        loading: false,
    };
};

const fetchBusinessByCategory = (state, action) => {
    return {
        ...state,
        busniess: action.busniess,
        loading: false,
    };
};
const fetchRandomBusiness = (state, action) => {
    return {
        ...state,
        random_businesses: action.random_businesses,
        loading: false,
    };
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.FETCH_CATEGORIES_START:
            return fetchCategoriesStart(state, action);
        case actionTypes.FETCH_CATEGORIES_SUCCESS:
            return fetchCategoriesSuccess(state, action);
        case actionTypes.FETCH_CATEGORIES_FAIL:
            return fetchCategoriesFail(state, action);
        case actionTypes.FETCH_BUSINESS_BY_CATEGORY:
            return fetchBusinessByCategory(state, action);
        case actionTypes.FETCH_RANDOM_BUSINESS:
            return fetchRandomBusiness(state, action);

        // case actionTypes.FETCH_PRODUCT_BY_CATEGORY:
        //     return fetchProductByCategory(state, action);

        // case actionTypes.SEARCH:
        //     const { value } = action;

        //     const productSearched = state.home.all_products.filter((val) => val.name.includes(value));

        //     return {
        //         ...state,
        //         productSearched: productSearched,
        //         value: value,
        //         searched: true,
        //     };
        // case actionTypes.SEARCH_RESET:
        //     return {
        //         ...state,
        //         productSearched: [],

        //         searched: false,
        //     };

        default:
            return state;
    }
};
export default reducer;
