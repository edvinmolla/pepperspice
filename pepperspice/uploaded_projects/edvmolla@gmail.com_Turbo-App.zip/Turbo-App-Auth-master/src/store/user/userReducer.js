import * as actionTypes from "./actionTypes";

const initialState = {
    user: [],
    addresses: [],
    loading: false,
    error: null,
};

const fetchUserStart = (state, action) => {
    return {
        ...state,
        loading: true,
    };
};
const fetchUserSuccess = (state, action) => {
    return {
        ...state,
        user: action.user,
        loading: false,
    };
};
const fetchUserFail = (state, action) => {
    return {
        ...state,
        loading: false,
    };
};

const fetchAddressesStart = (state, action) => {
    return {
        ...state,
        loading: true,
    };
};
const fetchAddressesSuccess = (state, action) => {
    return {
        ...state,
        addresses: action.addresses,
        loading: false,
    };
};
const fetchAddressesFail = (state, action) => {
    return {
        ...state,
        loading: false,
    };
};

const deleteAddressesSuccess = (state, action) => {
    const addressId = action.id;
    return {
        ...state,
        addresses: state.addresses.filter((address) => address.id !== addressId),
        loading: false,
    };
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.FETCH_USERINFO_START:
            return fetchUserStart(state, action);
        case actionTypes.FETCH_USERINFO_SUCCESS:
            return fetchUserSuccess(state, action);
        case actionTypes.FETCH_USERINFO_FAIL:
            return fetchUserFail(state, action);
        case actionTypes.FETCH_ADDRESS_START:
            return fetchAddressesStart(state, action);
        case actionTypes.FETCH_ADDRESS_SUCCESS:
            return fetchAddressesSuccess(state, action);
        case actionTypes.FETCH_ORDERS_FAIL:
            return fetchAddressesFail(state, action);
        case actionTypes.DELETE_ADDRESS:
            return deleteAddressesSuccess(state, action);

        default:
            return state;
    }
};
export default reducer;
