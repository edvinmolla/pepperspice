import * as actionTypes from "./actionTypes";
import axios from "axios";

export const fetchUserStart = () => {
    return {
        type: actionTypes.FETCH_USERINFO_START,
    };
};

export const fetchUserSuccess = (user) => {
    return {
        type: actionTypes.FETCH_USERINFO_SUCCESS,
        user: user,
    };
};

export const fetchUserFail = (error) => {
    return {
        type: actionTypes.FETCH_USERINFO_FAIL,
        error: error,
    };
};

export const fetchUser = (token) => {
    return (dispatch) => {
        dispatch(fetchUserStart());

        const config = {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        };

        axios
            .get("https://develop.almotech.co/turboo/public/api/profile", config)
            .then((res) => {
                let user = res.data.data;

                dispatch(fetchUserSuccess(user));
            })
            .catch((e) => {
                dispatch(fetchUserFail(e));
            });
    };
};

export const fetchAddressStart = () => {
    return {
        type: actionTypes.FETCH_ADDRESS_START,
    };
};

export const fetchAddressSuccess = (addresses) => {
    return {
        type: actionTypes.FETCH_ADDRESS_SUCCESS,
        addresses: addresses,
    };
};

export const fetchAddressFail = (error) => {
    return {
        type: actionTypes.FETCH_ADDRESS_FAIL,
        error: error,
    };
};

export const fetchAddresses = (token) => {
    return (dispatch) => {
        dispatch(fetchAddressStart());

        const config = {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        };

        axios
            .get("https://develop.almotech.co/turboo/public/api/address", config)
            .then((res) => {
                let addresses = res.data.data;

                dispatch(fetchAddressSuccess(addresses));
            })
            .catch((e) => {
                dispatch(fetchAddressFail(e));
            });
    };
};

export const deleteAddressSuccess = (id) => {
    return {
        type: actionTypes.DELETE_ADDRESS,
        id: id,
    };
};

export const deleteAddress = (id, token) => {
    return (dispatch) => {
        const config = {
            headers: {
                "content-type": "multipart/form-data",
                Authorization: `Bearer ${token}`,
            },
        };

        if (window.confirm("Delete the item?")) {
            axios
                .delete(`https://develop.almotech.co/turboo/public/api/address/${id}`, config)
                .then((response) => {
                    dispatch(deleteAddressSuccess(id));
                })
                .catch((error) => {
                    console.log(error.message);
                });
        }
    };
};
