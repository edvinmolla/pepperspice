import localeReducer from './localeReducer';

export * from './localeActions';
export default localeReducer;
