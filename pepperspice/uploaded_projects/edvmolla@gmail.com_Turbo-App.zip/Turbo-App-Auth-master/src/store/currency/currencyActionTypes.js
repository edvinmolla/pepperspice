// eslint-disable-next-line import/prefer-default-export
export const CURRENCY_CHANGE = 'CURRENCY_CHANGE';
