import * as actionTypes from "./typeActions";

const initialState = {
    home: [],
    products: [],
    loading: false,
    productSearched: [],
    value: "",
    searched: false,
};

const fetchHomeStart = (state, action) => {
    return {
        ...state,
        loading: true,
    };
};
const fetchHomeSuccess = (state, action) => {
    return {
        ...state,
        home: action.home,
        loading: false,
    };
};
const fetchHomeFail = (state, action) => {
    return {
        ...state,
        loading: false,
    };
};

const fetchProductByCategory = (state, action) => {
    return {
        ...state,
        products: action.products,
        loading: false,
    };
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.FETCH_HOMESTART:
            return fetchHomeStart(state, action);
        case actionTypes.FETCH_HOMESUCCES:
            return fetchHomeSuccess(state, action);
        case actionTypes.FETCH_HOME_FAIL:
            return fetchHomeFail(state, action);

        case actionTypes.FETCH_PRODUCT_BY_CATEGORY:
            return fetchProductByCategory(state, action);

        case actionTypes.SEARCH:
            const { value } = action;

            const productSearched = state.home.all_products.filter((val) => val.name.includes(value));

            return {
                ...state,
                productSearched: productSearched,
                value: value,
                searched: true,
            };
        case actionTypes.SEARCH_RESET:
            return {
                ...state,
                productSearched: [],

                searched: false,
            };

        default:
            return state;
    }
};
export default reducer;
