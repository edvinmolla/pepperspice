import reducer from "./homeReducer";

export * from "./homeActions";
export default reducer;
