import * as actionTypes from "./typeActions";
import axios from "axios";

export const fetchHomeStart = () => {
    return {
        type: actionTypes.FETCH_HOMESTART,
    };
};

export const fetchHomeSuccess = (home) => {
    return {
        type: actionTypes.FETCH_HOMESUCCES,
        home: home,
    };
};

export const fetchHomeFail = (error) => {
    return {
        type: actionTypes.FETCH_HOME_FAIL,
        error: error,
    };
};

export const fetchProductByIdSuccess = (products) => {
    return {
        type: actionTypes.FETCH_PRODUCT_BY_CATEGORY,
        products: products,
    };
};

export const fetchHome = () => {
    return (dispatch) => {
        dispatch(fetchHomeStart());

        const config = {
            headers: {
                Authorization: `Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI1IiwianRpIjoiZWE0OTZkNDRiNTMxOThmZTc3OTJlMzZiYzI1OTFmYTkzODFiMTg2NGE4NTljZjlkOGQ1MjNjY2EzMmQ2Mjc5MTQzNzdmMWJhNGRlZjZjZTciLCJpYXQiOjE1ODcxMjQ2NjEsIm5iZiI6MTU4NzEyNDY2MSwiZXhwIjoxNjE4NjYwNjYxLCJzdWIiOiIxIiwic2NvcGVzIjpbXX0.e4ftMKofbBWGQ0vk6yGZv0qLgQK2GqCuYWWL1LPdkZYCmESLwBNwSWEf81IrJAYRyY03CivjUTmAIPUqBLwy1sWJrBnF7z9ukV37fripZXk1EFi7-j1iQbuhPmZRDfvQxIZoilRE4NqBNnN0nDFv1f7tYldAZGrOHsZlVkjTUlSe55hs0Xw6kYVduSv63Y_jBRl5jssGp9xyxHwCWjVvy17z1tYlmhTX_UwAjXlZ-l4nrNwY033sJbqvjDW1506XrefG8fpPsJgm0S2VeWKHaRuatZn_8oFH56dPLvjGHs6X_bm5DKaAMwwFh8r6GW3aidZ5wwmc5_nSHiZ9CMdp-q97a2tj_v-m2RLeKPyZlp2zE6sV9sYfDfKc6ouzfVlhicM9QgUYokktm2mMMDLUWvHSuCvC4WlL_sacYdqnARpOyZ6FBMnLvuXfB6qqh0eJyuMuZwjZJWNhYyqu89dMmzesBi85NZZSHz4Jn9worIL5MSk5NOa9bzKvoJgc-z1GNamQkumQKRXOweQi-wfn-ymagB1e1PIhejVvPZik0vud5n0ZbUSSVEbq_8iJ0EvwZeP-gKkx9nmiXL-cxd569_iTI2imbWoOeeanQoCqa9QJysoKY7AUFetycpfUX8XLXBaF1cuFoMiChXbBTCkYVf9cFhHenycN9Y4gQ1uuAGs`,
            },
        };

        axios
            .get("http://develop.almotech.org/turboo/public/api/home", config)
            .then((res) => {
                let fetchHome = res.data;
                // fetchEmploye = res.data.data.doc;

                dispatch(fetchHomeSuccess(fetchHome));
            })
            .catch((e) => {
                dispatch(fetchHomeFail(e));
            });
    };
};

export const fethPorductByCategory = () => {
    return (dispatch) => {
        const config = {
            headers: {
                Authorization: `Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI1IiwianRpIjoiZWE0OTZkNDRiNTMxOThmZTc3OTJlMzZiYzI1OTFmYTkzODFiMTg2NGE4NTljZjlkOGQ1MjNjY2EzMmQ2Mjc5MTQzNzdmMWJhNGRlZjZjZTciLCJpYXQiOjE1ODcxMjQ2NjEsIm5iZiI6MTU4NzEyNDY2MSwiZXhwIjoxNjE4NjYwNjYxLCJzdWIiOiIxIiwic2NvcGVzIjpbXX0.e4ftMKofbBWGQ0vk6yGZv0qLgQK2GqCuYWWL1LPdkZYCmESLwBNwSWEf81IrJAYRyY03CivjUTmAIPUqBLwy1sWJrBnF7z9ukV37fripZXk1EFi7-j1iQbuhPmZRDfvQxIZoilRE4NqBNnN0nDFv1f7tYldAZGrOHsZlVkjTUlSe55hs0Xw6kYVduSv63Y_jBRl5jssGp9xyxHwCWjVvy17z1tYlmhTX_UwAjXlZ-l4nrNwY033sJbqvjDW1506XrefG8fpPsJgm0S2VeWKHaRuatZn_8oFH56dPLvjGHs6X_bm5DKaAMwwFh8r6GW3aidZ5wwmc5_nSHiZ9CMdp-q97a2tj_v-m2RLeKPyZlp2zE6sV9sYfDfKc6ouzfVlhicM9QgUYokktm2mMMDLUWvHSuCvC4WlL_sacYdqnARpOyZ6FBMnLvuXfB6qqh0eJyuMuZwjZJWNhYyqu89dMmzesBi85NZZSHz4Jn9worIL5MSk5NOa9bzKvoJgc-z1GNamQkumQKRXOweQi-wfn-ymagB1e1PIhejVvPZik0vud5n0ZbUSSVEbq_8iJ0EvwZeP-gKkx9nmiXL-cxd569_iTI2imbWoOeeanQoCqa9QJysoKY7AUFetycpfUX8XLXBaF1cuFoMiChXbBTCkYVf9cFhHenycN9Y4gQ1uuAGs`,
            },
        };

        axios
            .get("http://develop.almotech.org/turboo/public/api/products/21", config)
            .then((res) => {
                let fetchProducts = res.data;
                // fetchEmploye = res.data.data.doc;

                dispatch(fetchProductByIdSuccess(fetchProducts));
            })
            .catch((e) => {
                dispatch(fetchHomeFail(e));
            });
    };
};

export const search = (value) => {
    return {
        type: actionTypes.SEARCH,
        value: value,
    };
};

export const searchReset = () => {
    return {
        type: actionTypes.SEARCH_RESET,
    };
};
