export default [
    {
        type: "link",

        label: "Kryefaqja",
        url: "/",
    },
    {
        type: "link",
        label: "Kategorite",
        url: "/business",
    },

    { type: "link", label: "Rreth Nesh", url: "/site/about-us" },
    { type: "link", label: "Kontakt", url: "/site/contact-us" },
];
