export default [
    {
        title: "Kryefaqja",
        url: "/",
    },
    {
        title: "Kategorite",
        url: "/business",
    },

    { title: "Rreth Nesh", url: "/site/about-us" },
    { title: "Kontakt", url: "/site/contact-us" },
];
