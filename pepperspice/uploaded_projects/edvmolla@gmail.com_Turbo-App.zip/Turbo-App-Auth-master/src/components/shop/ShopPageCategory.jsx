/* eslint-disable arrow-body-style */
/* eslint-disable react/no-unused-prop-types */
/* eslint-disable object-curly-newline */
/* eslint-disable no-self-compare */
/* eslint-disable vars-on-top */
/* eslint-disable no-var */
/* eslint-disable react/destructuring-assignment */
/* eslint-disable prefer-arrow-callback */
/* eslint-disable func-names */
/* eslint-disable max-len */
// react
import React, { useEffect, useState } from "react";

// third-party
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Helmet } from "react-helmet-async";

// application
import CategorySidebar from "./CategorySidebar";

import ProductsView from "./ProductsView";
import { sidebarClose } from "../../store/sidebar";

import { fetchHome, fethPorductByCategory, searchReset } from "../../store/Home";

function ShopPageCategory(props) {
    const [categoryId, setCategoryId] = useState(0);

    const { columns, viewMode, onFetchHome, onFetchProductsByCategory } = props;

    let content;

    const offcanvas = columns === 3 ? "mobile" : "always";

    useEffect(() => {
        onFetchHome();
    }, []);
    useEffect(() => {
        onFetchProductsByCategory();
    }, []);

    const selectCategory = (category) => {
        setCategoryId(category);
    };

    const searchReset = () => {
        props.onSearchReset();
    };

    let categories = [];
    if (props.productsByCategory.data && props.productsByCategory.data.length > 0) {
        props.productsByCategory.data.forEach(function (o) {
            if (o.category_id) categories.push({ categoryId: o.category_id, categoryname: o.category_name });
        });
    }

    // if (columns > 3) {
    //     content = (
    //         <div className="container">
    //             <div className="block">
    //                 <ProductsView
    //                     products={props.home.all_products}
    //                     layout={viewMode}
    //                     grid={`grid-${columns}-full`}
    //                     limit={15}
    //                     offcanvas={offcanvas}
    //                 />
    //             </div>
    //             <CategorySidebar offcanvas={offcanvas} />
    //         </div>
    //     );
    // }

    if (categoryId === 0) {
        content = (
            <div className="container">
                <div className="block">
                    <ProductsView
                        products={props.searched ? props.productSearched : props.home && props.home.all_products}
                        layout={viewMode}
                        grid={`grid-${columns}-full`}
                        limit={15}
                        offcanvas={offcanvas}
                        searchReset={searchReset}
                    />
                </div>
                <CategorySidebar onselectCategory={selectCategory} categories={categories} offcanvas={offcanvas} />
            </div>
        );
    } else if (categoryId === categoryId) {
        let products = [];
        products = props.productsByCategory.data.filter(function (product) {
            return product.category_id === categoryId;
        });

        content = (
            <div className="container">
                <div className="block">
                    <ProductsView
                        products={props.searched ? props.productSearched : products[0].products}
                        layout={viewMode}
                        grid={`grid-${columns}-full`}
                        limit={15}
                        offcanvas={offcanvas}
                        searchReset={searchReset}
                    />
                </div>

                <CategorySidebar onselectCategory={selectCategory} categories={categories} offcanvas={offcanvas} />
            </div>
        );
    }

    return (
        <React.Fragment>
            <Helmet>
                <title>Trubo App</title>
            </Helmet>

            {content}
        </React.Fragment>
    );
}

ShopPageCategory.propTypes = {
    /**
     * number of product columns (default: 3)
     */
    columns: PropTypes.number,
    /**
     * mode of viewing the list of products (default: 'grid')
     * one of ['grid', 'grid-with-features', 'list']
     */
    viewMode: PropTypes.oneOf(["grid", "grid-with-features", "list"]),
    /**
     * sidebar position (default: 'start')
     * one of ['start', 'end']
     * for LTR scripts "start" is "left" and "end" is "right"
     */
    sidebarPosition: PropTypes.oneOf(["start", "end"]),
};

ShopPageCategory.defaultProps = {
    columns: 3,
    viewMode: "grid",
    sidebarPosition: "start",
};

const mapStateToProps = (state) => {
    return {
        sidebarState: state.sidebar,
        home: state.home.home,
        productsByCategory: state.home.products,
        productSearched: state.home.productSearched,
        valueSerch: state.home.value,
        searched: state.home.searched,
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        onFetchHome: () => dispatch(fetchHome()),
        onFetchProductsByCategory: () => dispatch(fethPorductByCategory()),
        onSearchReset: () => dispatch(searchReset()),

        sidebarClose,
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(ShopPageCategory);
