// react
import React, { useState } from "react";
import axios from "axios";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";

// application
import Pagination from "../shared/Pagination";
import Rating from "../shared/Rating";

// data stubs

function ProductTabReviews(props) {
    const [page, setpage] = useState(1);

    const [leaveReview, setLeaveReview] = useState({ review: "5", comment: "" });

    const { businessId, token, history } = props;

    const handleChange = (event) => {
        setLeaveReview({ ...leaveReview, [event.target.name]: event.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        const config = {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        };

        axios
            .post(`https://develop.almotech.co/turboo/public/api/review/${businessId}`, leaveReview, config)
            .then((response) => {
                history.push(`/business/${businessId}`);
            })
            .catch((error) => {
                console.log(error);
            });
    };

    let productPerPage = 5;

    const indexOfLastTodo = page * productPerPage;
    const indexOfFirstTodo = indexOfLastTodo - productPerPage;

    let currentReviews = props.reviews && props.reviews.slice(indexOfFirstTodo, indexOfLastTodo);
    const reviewsList =
        currentReviews &&
        currentReviews.map((review, index) => (
            <li key={index} className="reviews-list__item">
                <div className="review">
                    <div className="review__avatar">
                        <img src={review.avatar} alt="" />
                    </div>
                    <div className=" review__content">
                        <div className=" review__author">{review.user}</div>
                        <div className=" review__rating">
                            <Rating value={review.rating} />
                        </div>
                        <div className=" review__text">{review.comment}</div>
                        <div className=" review__date">{review.date}</div>
                    </div>
                </div>
            </li>
        ));

    let pageNumbers = [];
    for (let i = 1; i <= Math.ceil(props.reviews && props.reviews.length / productPerPage); i++) {
        pageNumbers.push(i);
    }

    const handlePageChange = (page) => {
        setpage(page);
    };
    return (
        <div className="reviews-view">
            <div className="reviews-view__list">
                <h3 className="reviews-view__header"> Reviews</h3>

                <div className="reviews-list">
                    <ol className="reviews-list__content">{reviewsList}</ol>
                    {reviewsList == 0 && <div className="reviews-list__content">No Reviews</div>}

                    <div className="reviews-list__pagination">
                        <Pagination
                            current={page}
                            siblings={2}
                            total={pageNumbers.length}
                            onPageChange={handlePageChange}
                        />
                    </div>
                </div>
            </div>

            <form className="reviews-view__form" onSubmit={handleSubmit}>
                <h3 className="reviews-view__header">Write A Review</h3>
                <div className="row">
                    <div className="col-12 col-lg-9 col-xl-8">
                        <div className="form-row">
                            <div className="form-group col-md-4">
                                <label htmlFor="review-stars">Review Stars</label>
                                <select
                                    id="review-stars"
                                    className="form-control"
                                    name="review"
                                    value={leaveReview.review}
                                    onChange={handleChange}
                                >
                                    <option value="5">5 Stars Rating</option>
                                    <option value="4">4 Stars Rating</option>
                                    <option value="3">3 Stars Rating</option>
                                    <option value="2">2 Stars Rating</option>
                                    <option value="1">1 Stars Rating</option>
                                </select>
                            </div>
                        </div>
                        <div className="form-group">
                            <label htmlFor="review-text">Your Review</label>
                            <textarea
                                className="form-control"
                                id="review-text"
                                name="comment"
                                rows="6"
                                value={leaveReview.comment}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div className="form-group mb-0">
                            {props.isAuth ? (
                                <button type="submit" className="btn btn-primary btn-lg">
                                    Post Your Review
                                </button>
                            ) : (
                                <button disabled className="btn btn-primary btn-lg">
                                    Login First
                                </button>
                            )}
                        </div>
                    </div>
                </div>
            </form>
        </div>
    );
}

const mapStateToProps = (state) => ({
    sidebarState: state.sidebar,
    token: state.auth.token,
    isAuth: state.auth.token !== null,
});

const mapDispatchToProps = (dispatch) => ({});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(ProductTabReviews));
