/* eslint-disable react-hooks/exhaustive-deps */

/* eslint-disable padded-blocks */
/* eslint-disable react/destructuring-assignment */
// react
import React, { useEffect, useState } from "react";

// third-party
import PropTypes from "prop-types";
import { Helmet } from "react-helmet-async";
import { connect } from "react-redux";
import axios from "axios";
import { fetchHome } from "../../store/Home";

// application
import PageHeader from "../shared/PageHeader";
import Product from "../shared/Product";
import ProductTabs from "./ProductTabs";

// blocks
import BlockProductsCarousel from "../blocks/BlockProductsCarousel";

// widgets
import WidgetCategories from "../widgets/WidgetCategories";
import WidgetProducts from "../widgets/WidgetProducts";

// data stubs
import categories from "../../data/shopWidgetCategories";
// import products from "../../data/shopProducts";
import theme from "../../data/theme";

function ShopPageProduct(props) {
    const { layout, sidebarPosition, match } = props;
    const [productF, setProductF] = useState();
    const products = props.home.all_products;


    useEffect(() => {
        const config = {
            headers: {
                Authorization: "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI1IiwianRpIjoiZWE0OTZkNDRiNTMxOThmZTc3OTJlMzZiYzI1OTFmYTkzODFiMTg2NGE4NTljZjlkOGQ1MjNjY2EzMmQ2Mjc5MTQzNzdmMWJhNGRlZjZjZTciLCJpYXQiOjE1ODcxMjQ2NjEsIm5iZiI6MTU4NzEyNDY2MSwiZXhwIjoxNjE4NjYwNjYxLCJzdWIiOiIxIiwic2NvcGVzIjpbXX0.e4ftMKofbBWGQ0vk6yGZv0qLgQK2GqCuYWWL1LPdkZYCmESLwBNwSWEf81IrJAYRyY03CivjUTmAIPUqBLwy1sWJrBnF7z9ukV37fripZXk1EFi7-j1iQbuhPmZRDfvQxIZoilRE4NqBNnN0nDFv1f7tYldAZGrOHsZlVkjTUlSe55hs0Xw6kYVduSv63Y_jBRl5jssGp9xyxHwCWjVvy17z1tYlmhTX_UwAjXlZ-l4nrNwY033sJbqvjDW1506XrefG8fpPsJgm0S2VeWKHaRuatZn_8oFH56dPLvjGHs6X_bm5DKaAMwwFh8r6GW3aidZ5wwmc5_nSHiZ9CMdp-q97a2tj_v-m2RLeKPyZlp2zE6sV9sYfDfKc6ouzfVlhicM9QgUYokktm2mMMDLUWvHSuCvC4WlL_sacYdqnARpOyZ6FBMnLvuXfB6qqh0eJyuMuZwjZJWNhYyqu89dMmzesBi85NZZSHz4Jn9worIL5MSk5NOa9bzKvoJgc-z1GNamQkumQKRXOweQi-wfn-ymagB1e1PIhejVvPZik0vud5n0ZbUSSVEbq_8iJ0EvwZeP-gKkx9nmiXL-cxd569_iTI2imbWoOeeanQoCqa9QJysoKY7AUFetycpfUX8XLXBaF1cuFoMiChXbBTCkYVf9cFhHenycN9Y4gQ1uuAGs",
            },
        };
        axios
            .get(`http://develop.almotech.org/turboo/public/api/product_details/${match.params.productId}`, config)
            .then((res) => {

                setProductF(res.data.product_detail);
            })
            .catch(() => {

            });



    }, []);
    let product;

    if (match.params.productId) {
        product = products.find((x) => x.id === parseFloat(match.params.productId));
    } else {
        product = products[products.length - 1];
    }

    const breadcrumb = [
        { title: "Home", url: "" },

        { title: product.name, url: "" },
    ];

    let content;

    if (layout === "sidebar") {
        const sidebar = (
            <div className="shop-layout__sidebar">
                <div className="block block-sidebar">
                    <div className="block-sidebar__item">
                        <WidgetCategories categories={categories} location="shop" />
                    </div>
                    <div className="block-sidebar__item d-none d-lg-block">
                        <WidgetProducts title="Latest Products" products={products.slice(0, 5)} />
                    </div>
                </div>
            </div>
        );

        content = (
            <div className="container">
                <div className={`shop-layout shop-layout--sidebar--${sidebarPosition}`}>
                    {sidebarPosition === "start" && sidebar}
                    <div className=" shop-layout__content">
                        <div className=" block">
                            <Product product={productF} layout={layout} />
                            <ProductTabs withSidebar />
                        </div>

                        <BlockProductsCarousel
                            title="Related Products"
                            layout="grid-4-sm"
                            products={products}
                            withSidebar
                        />
                    </div>
                    {sidebarPosition === "end" && sidebar}
                </div>
            </div>
        );
    } else {
        content = (
            <React.Fragment>
                <div className="block">
                    <div className="container">
                        <Product product={product} layout={layout} />
                        {/* <ProductTabs /> */}
                    </div>
                </div>

                <BlockProductsCarousel title="Related Products" layout="grid-5" products={products} />
            </React.Fragment>
        );
    }

    return (
        <React.Fragment>
            <Helmet>
                <title>{`${product.name} — ${theme.name}`}</title>
            </Helmet>

            <PageHeader breadcrumb={breadcrumb} />

            {content}
        </React.Fragment>
    );
}
const mapStateToProps = (state) => ({
    sidebarState: state.sidebar,
    home: state.home.home,
});

const mapDispatchToProps = (dispatch) => ({
    onFetchHome: () => dispatch(fetchHome()),
});

export default connect(mapStateToProps, mapDispatchToProps)(ShopPageProduct);

ShopPageProduct.propTypes = {
    /** one of ['standard', 'sidebar', 'columnar', 'quickview'] (default: 'standard') */
    layout: PropTypes.oneOf(["standard", "sidebar", "columnar", "quickview"]),
    /**
     * sidebar position (default: 'start')
     * one of ['start', 'end']
     * for LTR scripts "start" is "left" and "end" is "right"
     */
    sidebarPosition: PropTypes.oneOf(["start", "end"]),
};

ShopPageProduct.defaultProps = {
    layout: "standard",
    sidebarPosition: "start",
};
