// react
import React, { useEffect } from "react";

// third-party
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";

import { connect } from "react-redux";
// data stubs
// import addresses from "../../data/accountAddresses";
import allOrders from "../../data/accountOrders";

import noo from "../../svg/noAvatar.webp";

import { fetchUser, fetchAddresses } from "../../store/user";
function AccountPageDashboard(props) {
    const { token, user, addresses, onFetchUser, onFetchAddresess } = props;

    useEffect(() => {
        if (token) {
            const userToken = token && token;
            onFetchUser(userToken);
            onFetchAddresess(userToken);
        }
    }, [token]);

    const address = addresses[0];
    const orders = allOrders.slice(0, 3).map((order) => (
        <tr key={order.id}>
            <td>
                <Link to="/account/orders/5">#{order.id}</Link>
            </td>
            <td>{order.date}</td>
            <td>{order.status}</td>
            <td>{order.total}</td>
        </tr>
    ));

    let image;

    if (user.image === null) {
        image = <img src={`https://develop.almotech.co/turboo/public/storage/images/profile/${user.image}`} alt="d" />;
    } else {
        image = <img src={noo} alt="" />;
    }

    return (
        <div className="dashboard">
            <Helmet>
                <title>{`My Account `}</title>
            </Helmet>

            <div className="dashboard__profile card profile-card">
                <div className="card-body profile-card__body">
                    <div className="profile-card__avatar">
                        {/* <img
                            src={`https://develop.almotech.co/turboo/public/storage/images/profile/${user.image}`}
                            alt="d"
                        /> */}
                        {image}
                    </div>
                    <div className="profile-card__name">{user.name}</div>
                    <div className="profile-card__email">{user.email}</div>
                    <div className="profile-card__edit">
                        <Link to="profile" className="btn btn-secondary btn-sm">
                            Edit Profile
                        </Link>
                    </div>
                </div>
            </div>
            <div className="dashboard__address card address-card address-card--featured">
                {/* {address.default && <div className="address-card__badge">Default Address</div>} */}
                <div className="address-card__body">
                    <div className="address-card__name">{`${address && address.address} `}</div>
                    <div className="address-card__row">
                        <br />
                        {address && address.city}
                        <br />
                        {address && address.description}
                    </div>
                    <div className="address-card__row">
                        <div className="address-card__row-title">Phone Number</div>
                        <div className="address-card__row-content">{user && user.phone}</div>
                    </div>
                    <div className="address-card__row">
                        <div className="address-card__row-title">Email Address</div>
                        <div className="address-card__row-content">{user && user.email}</div>
                    </div>
                    <div className="address-card__footer">
                        <Link to="/account/addresses/5">Edit Address</Link>
                    </div>
                </div>
            </div>
            <div className="dashboard__orders card">
                <div className="card-header">
                    <h5>Recent Orders</h5>
                </div>
                <div className="card-divider" />
                <div className="card-table">
                    <div className="table-responsive-sm">
                        <table>
                            <thead>
                                <tr>
                                    <th>Order</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>{orders}</tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}
const mapStateToProps = (state) => ({
    sidebarState: state.sidebar,
    user: state.user.user,
    addresses: state.user.addresses,

    token: state.auth.token,
});

const mapDispatchToProps = (dispatch) => ({
    onFetchUser: (token) => dispatch(fetchUser(token)),
    onFetchAddresess: (token) => dispatch(fetchAddresses(token)),
});

export default connect(mapStateToProps, mapDispatchToProps)(AccountPageDashboard);
