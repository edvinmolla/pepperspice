// react
import React from "react";

// third-party
import { Helmet } from "react-helmet-async";
import axios from "axios";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";

// data stubs
const updateObject = (oldObject, updatedProperties) => {
    return {
        ...oldObject,
        ...updatedProperties,
    };
};

const checkValidity = (value, rules) => {
    let isValid = true;
    if (!rules) {
        return true;
    }

    if (rules.required) {
        isValid = value.trim() !== "" && isValid;
    }

    if (rules.minLength) {
        isValid = value.length >= rules.minLength && isValid;
    }

    if (rules.maxLength) {
        isValid = value.length <= rules.maxLength && isValid;
    }

    if (rules.isEmail) {
        const pattern = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
        isValid = pattern.test(value) && isValid;
    }

    if (rules.isNumeric) {
        const pattern = /^\d+$/;
        isValid = pattern.test(value) && isValid;
    }

    return isValid;
};

class AddAddress extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            controls: {
                lat: {
                    value: "78,1223",
                    validation: {
                        required: true,
                        isEmail: true,
                    },
                    valid: false,
                },
                lng: {
                    value: "987,12332",
                    validation: {
                        required: true,
                    },
                    valid: false,
                },
                city: {
                    value: "",
                    validation: {
                        required: true,
                    },
                    valid: false,
                },
                address: {
                    value: "",
                    validation: {
                        required: true,
                    },
                    valid: false,
                },
            },
        };
    }

    inputChangedHandler = (event, controlName) => {
        const updatedControls = updateObject(this.state.controls, {
            [controlName]: updateObject(this.state.controls[controlName], {
                value: event.target.value,
                valid: checkValidity(event.target.value, this.state.controls[controlName].validation),
            }),
        });
        this.setState({ controls: updatedControls });
    };

    onFormSubmit = (e) => {
        e.preventDefault();
        const formData = new FormData();
        // formData.append("image", this.state.file);
        formData.append("lat", this.state.controls.lat.value);
        formData.append("lng", this.state.controls.lng.value);
        formData.append("city", this.state.controls.city.value);
        formData.append("address", this.state.controls.address.value);

        const config = {
            headers: {
                "content-type": "multipart/form-data",
                Authorization: `Bearer ${this.props.token}`,
            },
        };
        axios
            .post("http://develop.almotech.org/turboo/public/api/address", formData, config)
            .then((response) => {
                alert(response.data.message);
                this.props.history.push("/account/addresses");
            })
            .catch((error) => {
                console.log(error.message);
            });
    };

    render() {
        return (
            <div className="card">
                <Helmet>
                    <title>{`New Address `}</title>
                </Helmet>

                <div className="card-header">
                    <h5>New Address</h5>
                </div>
                <div className="card-divider" />
                <div className="card-body">
                    <div className="row no-gutters">
                        <div className="col-12 col-lg-7 col-xl-6">
                            <div className="form-group">
                                <label htmlFor="profile-first-name"> City</label>
                                <input
                                    id="profile-first-name"
                                    type="text"
                                    className="form-control"
                                    placeholder="City"
                                    onChange={(event) => this.inputChangedHandler(event, "city")}
                                />
                            </div>

                            <div className="form-group">
                                <label htmlFor="profile-email"> Address</label>
                                <input
                                    id="profile-email"
                                    type="email"
                                    className="form-control"
                                    placeholder=" Address"
                                    onChange={(event) => this.inputChangedHandler(event, "address")}
                                />
                            </div>

                            <div className="form-group mt-5 mb-0">
                                <button onClick={this.onFormSubmit} className="btn btn-primary">
                                    Create
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
const mapStateToProps = (state) => ({
    user: state.user.user,

    token: state.auth.token,
});

const mapDispatchToProps = (dispatch) => ({});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(AddAddress));
