import React, { Component } from "react";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import { Logout } from "../../store/auth";

class onLogout extends Component {
    componentDidMount() {
        this.props.onLogout();
    }

    render() {
        return <Redirect to="/" />;
    }
}

const mapDispatchToProps = (dipsatch) => {
    return {
        onLogout: () => dipsatch(Logout()),
    };
};

export default connect(null, mapDispatchToProps)(onLogout);
