// react
import React from "react";
import "react-phone-input-2/lib/style.css";
// third-party
import { Helmet } from "react-helmet-async";

import CodeInput from "react-code-input";
import PhoneInput from "react-phone-input-2";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
// application
import PageHeader from "../shared/PageHeader";

// data stubs
import { sendCode, verifyCode } from "../../store/auth/index";

export class AccountPageLogin extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            step: 1,
            phoneNumber: "",
            code: "",
        };
    }

    nextStep = (e) => {
        const { step } = this.state;
        this.setState({
            step: step + 1,
        });

        this.props.onCodeSend(this.state.phoneNumber);
    };

    onSubmit = (e) => {
        e.preventDefault();
        this.props.onVerifyCode("36", this.state.code);
    };

    render() {
        const { code } = this.state;
        const breadcrumb = [
            { title: "Home", url: "" },
            { title: "Login", url: "" },
        ];

        let authRedirect = null;
        if (this.props.isAuthenticated) {
            authRedirect = <Redirect to="/" />;
        }

        return (
            <React.Fragment>
                <Helmet>
                    <title>{`Login `}</title>
                </Helmet>

                <PageHeader header="My Account" breadcrumb={breadcrumb} />

                <div className="block">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-6 d-flex">
                                <div className="card flex-grow-1 mb-md-0">
                                    {this.state.step === 1 && (
                                        <div className="card-body">
                                            <h3 className="card-title" style={{ textAlign: "center" }}>
                                                Login
                                            </h3>
                                            <form
                                                style={{
                                                    display: "flex",
                                                    justifyContent: "center",
                                                    alignItems: "center",
                                                }}
                                            >
                                                <div className="form-group">
                                                    <label htmlFor="login-email">Phone Number</label>
                                                    <PhoneInput
                                                        country={"al"}
                                                        onlyCountries={["al", "it"]}
                                                        value={this.state.phoneNumber}
                                                        onChange={(value) => this.setState({ phoneNumber: value })}
                                                    />
                                                </div>

                                                <button
                                                    type="next"
                                                    onClick={this.nextStep}
                                                    className="btn btn-primary "
                                                >
                                                    Next
                                                </button>
                                            </form>
                                        </div>
                                    )}
                                    {this.state.step === 2 && (
                                        <div className="card-body">
                                            {authRedirect}
                                            <h3 className="card-title" style={{ textAlign: "center" }}>
                                                Verification Code
                                            </h3>
                                            <form
                                                style={{
                                                    display: "flex",
                                                    justifyContent: "center",
                                                    alignItems: "center",
                                                }}
                                                onSubmit={this.onSubmit}
                                            >
                                                <div className="form-group">
                                                    <label htmlFor="login-email">Enter Your Verification Code</label>
                                                    <CodeInput
                                                        value={code}
                                                        onChange={(value) => this.setState({ code: value })}
                                                        type="text"
                                                        fields={6}
                                                    />
                                                    <button type="submit" className="btn btn-primary ">
                                                        Submit
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    )}
                                </div>
                            </div>
                            <div className="col-md-6 d-flex mt-4 mt-md-0">
                                <div className="card flex-grow-1 mb-0">
                                    <div className="card-body">
                                        <h3 className="card-title">Register</h3>
                                        <form>
                                            <div className="form-group">
                                                <label htmlFor="register-email">Email address</label>
                                                <input
                                                    id="register-email"
                                                    type="email"
                                                    className="form-control"
                                                    placeholder="Enter email"
                                                />
                                            </div>
                                            <div className="form-group">
                                                <label htmlFor="register-password">Password</label>
                                                <input
                                                    id="register-password"
                                                    type="password"
                                                    className="form-control"
                                                    placeholder="Password"
                                                />
                                            </div>
                                            <div className="form-group">
                                                <label htmlFor="register-confirm">Repeat Password</label>
                                                <input
                                                    id="register-confirm"
                                                    type="password"
                                                    className="form-control"
                                                    placeholder="Password"
                                                />
                                            </div>
                                            <button type="submit" className="btn btn-primary mt-2 mt-md-3 mt-lg-4">
                                                Register
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        isAuthenticated: state.auth.token != null,
        user_id: state.auth.user_id,
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        onCodeSend: (phone) => dispatch(sendCode(phone)),
        onVerifyCode: (id, code) => dispatch(verifyCode(id, code)),
    };
};
export default connect(mapStateToProps, mapDispatchToProps)(AccountPageLogin);
