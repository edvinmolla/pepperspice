// react
import React from "react";

// third-party
import { Helmet } from "react-helmet-async";
import axios from "axios";
import { connect } from "react-redux";

import noo from "../../svg/noAvatar.webp";

// data stubs
const updateObject = (oldObject, updatedProperties) => {
    return {
        ...oldObject,
        ...updatedProperties,
    };
};

const checkValidity = (value, rules) => {
    let isValid = true;
    if (!rules) {
        return true;
    }

    if (rules.required) {
        isValid = value.trim() !== "" && isValid;
    }

    if (rules.minLength) {
        isValid = value.length >= rules.minLength && isValid;
    }

    if (rules.maxLength) {
        isValid = value.length <= rules.maxLength && isValid;
    }

    if (rules.isEmail) {
        const pattern = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
        isValid = pattern.test(value) && isValid;
    }

    if (rules.isNumeric) {
        const pattern = /^\d+$/;
        isValid = pattern.test(value) && isValid;
    }

    return isValid;
};

class AccountPageProfile extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            controls: {
                email: {
                    value: this.props.user.email,
                    validation: {
                        required: true,
                        isEmail: true,
                    },
                    valid: false,
                },
                name: {
                    value: this.props.user.name,
                    validation: {
                        required: true,
                    },
                    valid: false,
                },
                phoneNumber: {
                    value: this.props.user.phone,
                    validation: {
                        required: true,
                    },
                    valid: false,
                },
                dateOfBirth: {
                    value: this.props.user.date_of_birth,
                    validation: {
                        required: true,
                    },
                    valid: false,
                },
            },
            file: null,
        };
    }

    inputChangedHandler = (event, controlName) => {
        const updatedControls = updateObject(this.state.controls, {
            [controlName]: updateObject(this.state.controls[controlName], {
                value: event.target.value,
                valid: checkValidity(event.target.value, this.state.controls[controlName].validation),
            }),
        });
        this.setState({ controls: updatedControls });
    };

    onChange = (e) => {
        this.setState({ file: e.target.files[0] });
    };

    onFormSubmit = (e) => {
        e.preventDefault();
        const formData = new FormData();
        // formData.append("image", this.state.file);
        formData.append("name", this.state.controls.name.value);
        formData.append("email", this.state.controls.email.value);
        formData.append("phone", this.state.controls.phoneNumber.value);
        formData.append("date_of_birth", this.state.controls.dateOfBirth.value);

        const config = {
            headers: {
                "content-type": "multipart/form-data",
                Authorization: `Bearer ${this.props.token}`,
            },
        };
        axios
            .post("http://develop.almotech.org/turboo/public/api/profile", formData, config)
            .then((response) => {
                alert(response.data.message);
            })
            .catch((error) => {
                console.log(error.message);
            });
    };

    render() {
        const { user } = this.props;
        let image;
        if (user.image === null) {
            image = (
                <img src={`https://develop.almotech.co/turboo/public/storage/images/profile/${user.image}`} alt="d" />
            );
        } else {
            image = <img src={noo} alt="" />;
        }

        return (
            <div className="card">
                <Helmet>
                    <title>{`Profile `}</title>
                </Helmet>

                <div className="card-header">
                    <h5>Edit Profile</h5>
                </div>
                <div className="card-divider" />
                <div className="card-body">
                    <div className="profile-card__avatar">{image}</div>
                    <div className="row no-gutters">
                        <div className="col-12 col-lg-7 col-xl-6">
                            <div className="form-group">
                                <input type="file" name="myImage" onChange={this.onChange} />
                            </div>
                            <div className="form-group">
                                <label htmlFor="profile-first-name"> Name</label>
                                <input
                                    id="profile-first-name"
                                    type="text"
                                    className="form-control"
                                    placeholder="First Name"
                                    defaultValue={user.name}
                                    onChange={(event) => this.inputChangedHandler(event, "name")}
                                />
                            </div>

                            <div className="form-group">
                                <label htmlFor="profile-email">Email Address</label>
                                <input
                                    id="profile-email"
                                    type="email"
                                    className="form-control"
                                    placeholder="Email Address"
                                    defaultValue={user.email}
                                    onChange={(event) => this.inputChangedHandler(event, "email")}
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="profile-phone">Phone Number</label>
                                <input
                                    id="profile-phone"
                                    type="text"
                                    className="form-control"
                                    placeholder="Phone Number"
                                    defaultValue={user.phone}
                                    onChange={(event) => this.inputChangedHandler(event, "phoneNumber")}
                                />
                            </div>
                            <div className="form-group">
                                <label htmlFor="profile-phone">Date of Birth</label>
                                <input
                                    id="date"
                                    type="date"
                                    className="form-control"
                                    placeholder="Date Of Birth"
                                    defaultValue={user.date_of_birth}
                                    onChange={(event) => this.inputChangedHandler(event, "dateOfBirth")}
                                />
                            </div>

                            <div className="form-group mt-5 mb-0">
                                <button onClick={this.onFormSubmit} className="btn btn-primary">
                                    Save
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
const mapStateToProps = (state) => ({
    user: state.user.user,

    token: state.auth.token,
});

const mapDispatchToProps = (dispatch) => ({});

export default connect(mapStateToProps, mapDispatchToProps)(AccountPageProfile);
