/* eslint-disable arrow-body-style */
/* eslint-disable max-len */
/* eslint-disable react/destructuring-assignment */
// react
import React, { Component } from "react";

// third-party
import PropTypes from "prop-types";
import { connect } from "react-redux";

// application

import { fetchHome } from "../../store/Home";

// data stubs
import BlockProductsCarousel from "./BlockProductsCarousel";

class BlockTabbedProductsCarousel extends Component {
    timeout;

    constructor(props) {
        super(props);

        this.state = {
            // products: this.props.home.last_products && this.props.home.last_products.slice(),
            loading: false,
            groups: [
                { id: 1, name: "All", current: true },
                { id: 2, name: "Power Tools", current: false },
                { id: 3, name: "Hand Tools", current: false },
                { id: 4, name: "Plumbing", current: false },
            ],
        };
    }

    componentDidMount = () => {
        this.props.onFetchHome();

        // eslint-disable-next-line react-hooks/exhaustive-deps
    };

    // componentDidUpdate = (prevState, prevProps) => {
    //     if (prevProps.home && prevProps.home.last_products !== this.props.home.last_products) {
    //         this.setState({
    //             ...this.state,
    //             products: this.props.home.last_products && this.props.home.last_products.slice(),
    //         });
    //     }
    // };

    componentWillUnmount() {
        clearTimeout(this.timeout);
    }

    handleChangeGroup = (newCurrentGroup) => {
        clearTimeout(this.timeout);

        const { groups } = this.state;
        const currentGroup = groups.find((group) => group.current);

        if (currentGroup && currentGroup.id === newCurrentGroup.id) {
            return;
        }

        this.setState((state) => ({
            loading: true,
            groups: state.groups.map((group) => ({ ...group, current: group.id === newCurrentGroup.id })),
        }));
    };

    render() {
        return (
            <BlockProductsCarousel
                products={this.props.home.last_products && this.props.home.last_products.slice()}
                {...this.props}
                {...this.state}
                onGroupClick={this.handleChangeGroup}
            />
        );
    }
}

const mapStateToProps = (state) => {
    return {
        sidebarState: state.sidebar,
        home: state.home.home,
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        onFetchHome: () => dispatch(fetchHome()),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(BlockTabbedProductsCarousel);

BlockTabbedProductsCarousel.propTypes = {
    title: PropTypes.string.isRequired,
    layout: PropTypes.oneOf(["grid-4", "grid-4-sm", "grid-5", "horizontal"]),
    rows: PropTypes.number,
    withSidebar: PropTypes.bool,
};

BlockTabbedProductsCarousel.defaultProps = {
    layout: "grid-4",
    rows: 1,
    withSidebar: false,
};
