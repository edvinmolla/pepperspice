// react
import React, { useEffect } from "react";

// third-party
import PropTypes from "prop-types";
import { connect } from "react-redux";

// application
import BlockHeader from "../shared/BlockHeader";
import ProductCard from "../shared/ProductCard";

import { fetchHome } from "../../store/Home";

function BlockProducts(props) {
    const { title, layout, products, onFetchHome } = props;

    let large;
    let smalls;

    useEffect(() => {
        onFetchHome();

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    if (products.length > 0) {
        const productsList =
            props.home.offers &&
            props.home.offers.slice(0, 6).map((product, index) => (
                <div key={index} className="block-products__list-item">
                    <ProductCard product={product} />
                </div>
            ));

        smalls = <div className="block-products__list">{productsList}</div>;
    }

    return (
        <div className={`block block-products block-products--layout--${layout}`}>
            <div className="container">
                <BlockHeader title={title} />

                <div className="block-products__body">
                    {layout === "large-first" && large}
                    {smalls}
                    {layout === "large-last" && large}
                </div>
            </div>
        </div>
    );
}

const mapStateToProps = (state) => ({
    sidebarState: state.sidebar,
    home: state.home.home,
});

const mapDispatchToProps = (dispatch) => {
    return {
        onFetchHome: () => dispatch(fetchHome()),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(BlockProducts);

BlockProducts.propTypes = {
    title: PropTypes.string.isRequired,
    featuredProduct: PropTypes.object.isRequired,
    products: PropTypes.array,
    layout: PropTypes.oneOf(["large-first", "large-last"]),
};

BlockProducts.defaultProps = {
    products: [],
    layout: "large-first",
};
