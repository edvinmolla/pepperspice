// react
import React from "react";

// third-party
import { Helmet } from "react-helmet-async";

// blocks

import BlockFeatures from "../blocks/BlockFeatures";

import BlockProducts from "../blocks/BlockProducts";
import BlockSlideShow from "../blocks/BlockSlideShow";
import BlockTabbedProductsCarousel from "../blocks/BlockTabbedProductsCarousel";
import ShopPageCategory from "../shop/ShopPageCategory";

// data stubs

import products from "../../data/shopProducts";


function HomePageTwo(props) {
    return (
        <React.Fragment>
            <Helmet>{/* <title>{`Home Page Two — ${theme.name}`}</title> */}</Helmet>

            <BlockSlideShow />

            <BlockFeatures layout="boxed" />
            <BlockProducts
                title="FlashDeals"
                layout="large-last"
                featuredProduct={products[0]}
                products={products.slice(1, 7)}
            />
            <BlockTabbedProductsCarousel title="New Arrivals" layout="grid-5" />

            <ShopPageCategory {...props} columns={5} viewMode="grid" />
        </React.Fragment>
    );
}

export default HomePageTwo;
