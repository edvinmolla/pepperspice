// react
import React from "react";

// third-party
import { Link } from "react-router-dom";
import { connect } from "react-redux";
// application
import Indicator from "./Indicator";
import { Person20Svg } from "../../svg";
import { Logout } from "../../store/auth/index";
import noo from "../../svg/noAvatar.webp";

function IndicatorAccount(props) {
    let user = props.user;

    const dropdown = (
        <div className="account-menu">
            <div className="account-menu__divider" />
            <Link to="/account/dashboard" className="account-menu__user">
                <div className="account-menu__user-avatar">
                    <img src={noo} alt="" />
                </div>
                <div className="account-menu__user-info">
                    <div className="account-menu__user-name">{user && user.name}</div>
                    <div className="account-menu__user-email">{user && user.email}</div>
                </div>
            </Link>
            <div className="account-menu__divider" />
            <ul className="account-menu__links">
                <li>
                    <Link to="/account/orders">Order History</Link>
                </li>
                <li>
                    <Link to="/account/addresses">Addresses</Link>
                </li>
                <li>
                    <Link to="/account/dashboard">Settings</Link>
                </li>
            </ul>
            <div className="account-menu__divider" />
            <ul className="account-menu__links">
                <li>
                    <Link to="/logout">Logout</Link>
                </li>
            </ul>
        </div>
    );
    let content;

    if (props.isAuthenticated) {
        content = <Indicator url="/account" dropdown={dropdown} icon={<Person20Svg />} />;
    } else {
        content = <Indicator url="/account/login" icon={<Person20Svg />} />;
    }

    return content;
}

const mapStateToProps = (state) => {
    return {
        isAuthenticated: state.auth.token != null,
        user_id: state.auth.user_id,
        user: state.auth.user,
    };
};
const mapDispatchToProps = (dipsatch) => {
    return {
        onLogout: () => dipsatch(Logout()),
    };
};
export default connect(mapStateToProps, mapDispatchToProps)(IndicatorAccount);
