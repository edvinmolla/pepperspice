/* eslint-disable indent */
/* eslint-disable react/jsx-indent */
/* eslint-disable consistent-return */
/* eslint-disable padded-blocks */
/* eslint-disable react/destructuring-assignment */
// react
import React, {
    useCallback, useEffect, useRef, useState,
} from "react";

// third-party
import classNames from "classnames";
import { withRouter } from "react-router-dom";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { search } from "../../store/Home/index";

// application
import { Cross20Svg, Search20Svg } from "../../svg";
import Suggestions from "./Suggestions";

// data stubs

function Search(props) {
    const {
        context, className, inputRef, onClose, location, search,
    } = props;

    const [suggestionsOpen, setSuggestionsOpen] = useState(false);
    const [hasSuggestions, setHasSuggestions] = useState(false);
    const [suggestedProducts, setSuggestedProducts] = useState([]);
    const [query, setQuery] = useState("");

    const wrapper = useRef(null);
    const close = useCallback(() => {
        if (onClose) {
            onClose();
        }

        setSuggestionsOpen(false);
    }, [onClose]);

    useEffect(() => close(), [close, location]);

    useEffect(() => {
        const onGlobalClick = (event) => {
            if (wrapper.current && !wrapper.current.contains(event.target)) {
                close();
            }
        };

        document.addEventListener("mousedown", onGlobalClick);

        return () => document.removeEventListener("mousedown", onGlobalClick);
    }, [close]);

    useEffect(() => {
        if (query === "") {
            setHasSuggestions(false);

            return undefined;
        }

        // Use ajax request instead of timeout.

        setSuggestedProducts(props.home.all_products.slice(0, 5));
        setHasSuggestions(true);
        setSuggestionsOpen(true);

        // eslint-disable-next-line react-hooks/exhaustive-deps

    }, [query, props.home.all_products]);

    const handleFocus = () => {
        setSuggestionsOpen(true);
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        search(query);
    };

    const handleChangeQuery = (event) => {
        const v = event.target.value;


        setQuery(v);
    };

    const handleBlur = () => {
        setTimeout(() => {
            if (!document.activeElement || document.activeElement === document.body) {
                return;
            }

            // Close suggestions if the focus received an external element.
            if (wrapper.current && !wrapper.current.contains(document.activeElement)) {
                close();
            }
        }, 10);
    };

    const handleKeyDown = (event) => {
        // Escape.
        if (event.which === 27) {
            close();
        }
    };

    const rootClasses = classNames(`search search--location--${context}`, className, {
        "search--suggestions-open": suggestionsOpen,
        "search--has-suggestions": hasSuggestions,
    });

    const closeButton = context !== "mobile-header" ? (
        ""
    ) : (
            <button className="search__button search__button--type--close" type="button" onClick={close}>
                <Cross20Svg />
            </button>
        );

    return (
        <div className={rootClasses} ref={wrapper} onBlur={handleBlur}>
            <div className="search__body">
                <form className="search__form" action="" onSubmit={handleSubmit}>
                    <input
                        ref={inputRef}
                        // onChange={(event) => {
                        //     handleChange(event);
                        // }}
                        onChange={handleChangeQuery}
                        onFocus={handleFocus}
                        onKeyDown={handleKeyDown}
                        value={query}
                        className="search__input"
                        name="search"
                        placeholder="Search over 10,000 products"
                        aria-label="Site search"
                        type="text"
                        autoComplete="off"
                    // onChange={(e) => search(e.target.value)}
                    />
                    <button className="search__button search__button--type--submit" type="submit">
                        <Search20Svg />
                    </button>
                    {closeButton}
                    <div className="search__border" />
                </form>

                <Suggestions className="search__suggestions" context={context} products={suggestedProducts} />
            </div>
        </div>
    );
}

const mapStateToProps = (state) => ({
    sidebarState: state.sidebar,
    home: state.home.home,
    value: state.home.value,
    productsByCategory: state.home.products,
});

function mapDispatchToProps(dispatch) {
    return bindActionCreators({ search }, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(Search));
