// react
import React, { useEffect } from "react";

// third-party
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Helmet } from "react-helmet-async";

// application
import CategorySidebar from "../shop/CategorySidebar";
import PageHeader from "../shared/PageHeader";
import ProductsView from "../shop/ProductsView";
import BusinessView from "./BusinessView";
import { sidebarClose } from "../../store/sidebar";
import { fetchBusinessCategory, onfetchBusinessByCategory } from "../../store/business/";

// data stubs
import products from "../../data/shopProducts";

function BussnesByCategory(props) {
    const { columns, viewMode, sidebarPosition, onFetchCategory, onFetchBusinessByCategory, token } = props;

    const breadcrumb = [
        { title: "Home", url: "" },

        { title: "Categories", url: "/shop/business" },
    ];
    let content;

    useEffect(() => {
        onFetchCategory(token);
        return () => {
            onFetchCategory();
        };
    }, []);

    // useEffect(() => {
    //     onFetchBusinessByCategory(businessCategoryId);
    // }, []);

    // useEffect(() => {
    //     onFetchBusinessByCategory(businessCategoryId);

    //     return () => {
    //         onFetchBusinessByCategory(businessCategoryId);
    //     };
    // }, []);

    const selectBusinessCategory = (id) => {
        onFetchBusinessByCategory(id, token);
    };

    const offcanvas = columns === 3 ? "mobile" : "always";

    if (columns > 3) {
        content = (
            <div className="container">
                <div className="block">
                    <ProductsView
                        products={products}
                        layout={viewMode}
                        grid={`grid-${columns}-full`}
                        limit={15}
                        offcanvas={offcanvas}
                    />
                </div>
                <CategorySidebar offcanvas={offcanvas} />
            </div>
        );
    } else {
        const sidebar = (
            <div className="shop-layout__sidebar">
                <CategorySidebar
                    selectBusinessCategory={selectBusinessCategory}
                    categoriesBusiness={props.businessCategory.data}
                    offcanvas={offcanvas}
                />
            </div>
        );

        content = (
            <div className="container">
                <div className={`shop-layout shop-layout--sidebar--${sidebarPosition}`}>
                    {sidebarPosition === "start" && sidebar}
                    <div className="shop-layout__content">
                        <div className="block">
                            <BusinessView
                                AllBusiness={props.businessByCategory && props.businessByCategory.all_businesses}
                                most_rated={props.businessByCategory && props.businessByCategory.most_rated}
                                new_businesses={props.businessByCategory && props.businessByCategory.new_businesses}
                                businessRandom={props.randomBusiness}
                                layout={viewMode}
                                grid="grid-3-sidebar"
                                limit={15}
                                offcanvas={offcanvas}
                            />
                        </div>
                    </div>
                    {sidebarPosition === "end" && sidebar}
                </div>
            </div>
        );
    }

    return (
        <React.Fragment>
            <Helmet>
                <title>{`Business`}</title>
            </Helmet>

            <PageHeader breadcrumb={breadcrumb} />

            {content}
        </React.Fragment>
    );
}

BussnesByCategory.propTypes = {
    /**
     * number of product columns (default: 3)
     */
    columns: PropTypes.number,
    /**
     * mode of viewing the list of products (default: 'grid')
     * one of ['grid', 'grid-with-features', 'list']
     */
    viewMode: PropTypes.oneOf(["grid", "grid-with-features", "list"]),
    /**
     * sidebar position (default: 'start')
     * one of ['start', 'end']
     * for LTR scripts "start" is "left" and "end" is "right"
     */
    sidebarPosition: PropTypes.oneOf(["start", "end"]),
};

BussnesByCategory.defaultProps = {
    columns: 3,
    viewMode: "grid",
    sidebarPosition: "start",
};

const mapStateToProps = (state) => {
    return {
        sidebarState: state.sidebar,
        businessCategory: state.business.categories,
        randomBusiness: state.business.random_businesses,

        businessByCategory: state.business.busniess,
        token: state.auth.token,
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        sidebarClose,
        onFetchCategory: (token) => dispatch(fetchBusinessCategory(token)),
        onFetchBusinessByCategory: (id, token) => dispatch(onfetchBusinessByCategory(id, token)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(BussnesByCategory);
