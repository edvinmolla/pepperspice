// react
import React, { Component } from "react";

// third-party
import classNames from "classnames";
import PropTypes from "prop-types";
import { connect } from "react-redux";

// application
import Pagination from "../shared/Pagination";

import BusinessCard from "./BusinessCard";
import { Filters16Svg } from "../../svg";
import { sidebarOpen } from "../../store/sidebar";

class ProductsView extends Component {
    constructor(props) {
        super(props);

        this.state = {
            page: 1,
            productPerPage: 12,
            // sortByAz: false,
            show: 0,
        };
    }
    setProductPerPage = (e) => {
        const productPerPage = e.target.value;

        this.setState({ productPerPage });
    };

    setLayout = (layout) => {
        this.setState(() => ({ layout }));
    };

    handlePageChange = (page) => {
        this.setState(() => ({ page }));
    };
    handleShowChange = (show) => {
        this.setState({ show: show });
    };

    render() {
        const {
            businessRandom,
            grid,
            offcanvas,
            layout: propsLayout,
            sidebarOpen,
            AllBusiness,
            most_rated,
            new_businesses,
        } = this.props;
        const { page, layout: stateLayout } = this.state;
        const layout = stateLayout || propsLayout;

        let showMode = [
            { key: "grid", value: 0, title: "Show All" },
            { key: "grid-with-features", value: 1, title: "Most Rated" },
            { key: "list", value: 2, title: "New Busnisses" },
        ];

        showMode = showMode.map((showMode) => {
            const className = classNames("layout-switcher__button", {
                "layout-switcher__button--active": showMode.value === this.state.show,
            });

            return (
                <button
                    key={showMode.key}
                    title={showMode.title}
                    type="button"
                    className={className}
                    onClick={() => this.handleShowChange(showMode.value)}
                >
                    {showMode.title}
                </button>
            );
        });

        const { productPerPage } = this.state;
        const indexOfLastTodo = page * productPerPage;
        const indexOfFirstTodo = indexOfLastTodo - productPerPage;

        // let currentProduct = business && business.slice(indexOfFirstTodo, indexOfLastTodo);

        // const productsList =
        //     currentProduct &&
        //     currentProduct.map((product) => (
        //         <div key={product.id} className="products-list__item">
        //             <BusinessCard product={product} />
        //         </div>
        //     ));

        let productsListTest;
        let currentProductTest;
        if (this.state.show === 0 && AllBusiness) {
            currentProductTest = AllBusiness && AllBusiness.slice(indexOfFirstTodo, indexOfLastTodo);
            productsListTest =
                currentProductTest &&
                currentProductTest.map((product) => (
                    <div key={product.id} className="products-list__item">
                        <BusinessCard product={product} />
                    </div>
                ));
        } else if (this.state.show === 1 && most_rated) {
            currentProductTest = most_rated && most_rated.slice(indexOfFirstTodo, indexOfLastTodo);
            productsListTest =
                currentProductTest &&
                currentProductTest.map((product) => (
                    <div key={product.id} className="products-list__item">
                        <BusinessCard product={product} />
                    </div>
                ));
        } else if (this.state.show === 2 && new_businesses) {
            currentProductTest = new_businesses && new_businesses.slice(indexOfFirstTodo, indexOfLastTodo);
            productsListTest =
                currentProductTest &&
                currentProductTest.map((product) => (
                    <div key={product.id} className="products-list__item">
                        <BusinessCard product={product} />
                    </div>
                ));
        } else {
            currentProductTest = businessRandom && businessRandom.slice(indexOfFirstTodo, indexOfLastTodo);

            productsListTest =
                currentProductTest &&
                currentProductTest.map((product) => (
                    <div key={product.id} className="products-list__item">
                        <BusinessCard product={product} />
                    </div>
                ));
        }

        let pageNumbers = [];
        if (this.state.show === 0 && AllBusiness) {
            for (let i = 1; i <= Math.ceil(AllBusiness && AllBusiness.length / productPerPage); i++) {
                pageNumbers.push(i);
            }
        } else if (this.state.show === 1 && most_rated) {
            for (let i = 1; i <= Math.ceil(most_rated && most_rated.length / productPerPage); i++) {
                pageNumbers.push(i);
            }
        } else if (this.state.show === 2 && new_businesses) {
            for (let i = 1; i <= Math.ceil(new_businesses && new_businesses.length / productPerPage); i++) {
                pageNumbers.push(i);
            }
        } else {
            for (let i = 1; i <= Math.ceil(businessRandom && businessRandom.length / productPerPage); i++) {
                pageNumbers.push(i);
            }
        }

        const viewOptionsClasses = classNames("view-options", {
            "view-options--offcanvas--always": offcanvas === "always",
            "view-options--offcanvas--mobile": offcanvas === "mobile",
        });

        return (
            <div className="products-view">
                <div className="products-view__options">
                    <div className={viewOptionsClasses}>
                        <div className="view-options__filters-button">
                            <button type="button" className="filters-button" onClick={() => sidebarOpen()}>
                                <Filters16Svg className="filters-button__icon" />
                                <span className="filters-button__title">Filters</span>
                            </button>
                        </div>

                        <div className="view-options__layout">
                            <div className="layout-switcher">
                                {AllBusiness && new_businesses && most_rated ? (
                                    <div className="layout-switcher__list">{showMode}</div>
                                ) : null}
                            </div>
                        </div>

                        {/* <div className="view-options__legend">
                            Showing {this.state.productPerPage} of {businessRandom && businessRandom.length} businesses
                        </div> */}
                        <div className="view-options__divider" />

                        <div className="view-options__control">
                            <label htmlFor="view-options-limit">Show</label>
                            <div>
                                <select
                                    className="form-control form-control-sm"
                                    name=""
                                    id="view-options-limit"
                                    value={this.state.productPerPage}
                                    onChange={this.setProductPerPage}
                                >
                                    <option value="12">12</option>
                                    <option value="24">24</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <div
                    className="products-view__list products-list"
                    data-layout={layout !== "list" ? grid : layout}
                    data-with-features={layout === "grid-with-features" ? "true" : "false"}
                >
                    <div className="products-list__body">{productsListTest}</div>
                </div>

                <div className="products-view__pagination">
                    <Pagination
                        current={page}
                        siblings={2}
                        total={pageNumbers.length}
                        onPageChange={this.handlePageChange}
                    />
                </div>
            </div>
        );
    }
}

ProductsView.propTypes = {
    /**
     * array of product objects
     */
    // products: PropTypes.object,
    /**
     * products list layout (default: 'grid')
     * one of ['grid', 'grid-with-features', 'list']
     */
    layout: PropTypes.oneOf(["grid", "grid-with-features", "list"]),
    /**
     * products list layout (default: 'grid')
     * one of ['grid-3-sidebar', 'grid-4-full', 'grid-5-full']
     */
    grid: PropTypes.oneOf(["grid-3-sidebar", "grid-4-full", "grid-5-full"]),
    /**
     * indicates when sidebar bar should be off canvas
     */
    offcanvas: PropTypes.oneOf(["always", "mobile"]),
};

ProductsView.defaultProps = {
    products: [],
    layout: "grid",
    grid: "grid-3-sidebar",
    offcanvas: "mobile",
};

const mapDispatchToProps = {
    sidebarOpen,
};

export default connect(() => ({}), mapDispatchToProps)(ProductsView);
