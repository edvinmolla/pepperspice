// react
import React, { Component } from "react";

// third-party

import PropTypes from "prop-types";
import { connect } from "react-redux";

// application

import ProductGallery from "../shared/ProductGallery";

class Business extends Component {
    constructor(props) {
        super(props);

        this.state = {
            quantity: 1,
        };
    }

    handleChangeQuantity = (quantity) => {
        this.setState({ quantity });
    };

    render() {
        const { product, layout } = this.props;

        let image;

        if (product && product.data.image) {
            image = (
                <img
                    src={`https://develop.almotech.co/turboo/public/storage/images/business/${product.data.image}`}
                    alt=""
                />
            );
        } else if (product && product.data.image === null) {
            image = <img src="./noPhoto.jpg" alt="" />;
        }

        let prices;

        return (
            <div className={`product product--layout--${layout}`}>
                <div className="product__content">
                    <div className="product__gallery">
                        <div className="product-gallery">{image}</div>
                    </div>

                    <div className="product__info">
                        <div className="product__wishlist-compare"></div>
                        <h1 className="product__name">{product && product.data.name}</h1>

                        <div className="product__description">{product && product.data.description}</div>

                        <ul className="product__meta">
                            <li className="product__meta-availability">
                                Address: <span className="text-info"> {product && product.data.address}</span>
                            </li>
                            <li className="product__meta-availability">
                                Open Hours(WeekDay):{" "}
                                <span className="text-success"> {product && product.data.open_hours_weekday}</span>
                            </li>
                            <li>
                                Open Hours(WeekEnd):{" "}
                                <span className="text-success"> {product && product.data.open_hours_weekend}</span>
                            </li>
                            <li>Delivery :{product && product.data.delivery} ALL</li>
                        </ul>
                    </div>

                    <div className="product__sidebar">
                        <div className="product__availability">
                            Availability: <span className="text-success">In Stock</span>
                        </div>

                        <div className="product__prices">{prices}</div>
                    </div>

                    <div className="">
                        <ProductGallery layout={layout} images={product && product.data.multiple_images} />
                    </div>
                </div>
            </div>
        );
    }
}

Business.propTypes = {
    /** product object */
    // product: PropTypes.object.isRequired,
    /** one of ['standard', 'sidebar', 'columnar', 'quickview'] (default: 'standard') */
    layout: PropTypes.oneOf(["standard", "sidebar", "columnar", "quickview"]),
};

Business.defaultProps = {
    layout: "standard",
};

const mapDispatchToProps = {};

export default connect(() => ({}), mapDispatchToProps)(Business);
