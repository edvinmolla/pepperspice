/* eslint-disable padded-blocks */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/anchor-is-valid */
// react
import React from "react";

// third-party
import PropTypes from "prop-types";

// application
import { ArrowRoundedRight6x9Svg } from "../../svg";

function FilterCategories(props) {
    const { categories, onselectCategory, categoriesBusiness, selectBusinessCategory } = props;

    onselect = (id) => {
        onselectCategory(id);
    };

    const onSelectBusinessCategory = (categoriesId) => {
        selectBusinessCategory(categoriesId);
    };

    let categoriesList;
    if (categories) {
        categoriesList = categories.map((category) => {
            return (
                <li
                    key={category.categoryId}
                    className={`filter-categories__item filter-categories__item--${category.type}`}
                >
                    <div onClick={() => onselect(category.categoryId)}>{category.categoryname}</div>
                    <div className="filter-categories__counter">{category.count}</div>
                </li>
            );
        });
    }
    if (categoriesBusiness) {
        categoriesList = categoriesBusiness.map((category) => {
            return (
                <li key={category.id} className={`filter-categories__item filter-categories__item--child`}>
                    <button
                        type="button"
                        className="filter__title"
                        onClick={() => onSelectBusinessCategory(category.id)}
                    >
                        <ArrowRoundedRight6x9Svg className="filter-categories__arrow" />

                        {category.name}
                    </button>

                    <div className="filter-categories__counter">{category.count}</div>
                </li>
            );
        });
    }

    return (
        <div className="filter-categories">
            <ul className="filter-categories__list">{categoriesList}</ul>
        </div>
    );
}

FilterCategories.propTypes = {
    categories: PropTypes.array,
};

export default FilterCategories;
