// react
import React from "react";

// third-party
import classNames from "classnames";
import PropTypes from "prop-types";

// application

import FilterCategories from "../filters/FilterCategories";

function WidgetFilters(props) {
    const { title, offcanvas, categories, onselectCategory, categoriesBusiness, selectBusinessCategory } = props;

    const classes = classNames("widget-filters widget", {
        "widget-filters--offcanvas--always": offcanvas === "always",
        "widget-filters--offcanvas--mobile": offcanvas === "mobile",
    });

    return (
        <div className={classes}>
            <h4 className="widget-filters__title widget__title">{title}</h4>

            <div className="widget-filters__list">
                {" "}
                <FilterCategories
                    onselectCategory={onselectCategory}
                    selectBusinessCategory={selectBusinessCategory}
                    categories={categories}
                    categoriesBusiness={categoriesBusiness}
                />
            </div>

            <div className="widget-filters__actions d-flex">
                {/* <button onClick={() => onselectCategory(0)} type="button" className="btn btn-secondary btn-sm ml-2">
                    Reset
                </button> */}
            </div>
        </div>
    );
}

WidgetFilters.propTypes = {
    /**
     * widget title
     */
    title: PropTypes.node,
    /**
     * array of filters
     */
    filters: PropTypes.array,
    /**
     * indicates when sidebar bar should be off canvas
     */
    offcanvas: PropTypes.oneOf(["always", "mobile"]),
};

WidgetFilters.defaultProps = {
    filters: [],
    offcanvas: "mobile",
};

export default WidgetFilters;
